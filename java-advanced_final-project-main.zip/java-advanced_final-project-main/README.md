# -java-advanced_final-project


<br />
JPA: <br />
not sure need to insall posgres. but DO need to add postgres as a dependency to the maven projet <br />
<br />
<br />
<br />
First, install postgers: https://www.enterprisedb.com/downloads/postgres-postgresql-downloads <br />
for PostgeSQL: https://jdbc.postgresql.org/download/ <br />
how to set the driver: https://jdbc.postgresql.org/documentation/use/ <br />
restart postgras password: https://www.postgresqltutorial.com/postgresql-administration/postgresql-reset-password/ <br />



netbeans: <br />
https://www.apache.org/dyn/closer.cgi/netbeans/netbeans-installers/17/Apache-NetBeans-17-bin-windows-x64.exe <br />


---------------------------------------------------<br />
google calender API: <br />
https://developers.google.com/calendar/api/quickstart/java <br />
