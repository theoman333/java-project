package demo;

public class Main {
    public static void main(String[] args) {
        Runner.doLogic();
        new CalendarQuickstart();
    }
}
