package demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

@Entity
public class UserEvents extends Events{
    @GeneratedValue
    private Boolean done;
}
