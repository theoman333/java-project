Create Table Artist(
    Artist_ID varchar(5),
    Artist_Name varchar(30) NOT NULL,
    Primary Key(Artist_Name)
);


Create Table Show(
    Show_ID int,
    Show_Time TIME,
    Show_Location varchar(30) NOT NULL,
    Avaliable_seats int,
    Art_Name varchar(30) NOT NULL,
    Primary Key(Show_ID),
    CONSTRAINT fk_artName
    Foreign Key(Art_Name) 
        REFERENCES Artist(Artist_Name) 
            ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO Artist (Artist_ID, Artist_Name) 
	VALUES (1, 'Ed Sheeran'),
     (2, 'Shakira'),
     (3, 'Beyonce'),
     (4, 'Dylan');
     
INSERT INTO show (show_id, show_time, show_location, avaliable_seats, art_name) 
	VALUES (1, CURRENT_TIME, 'LA', 50, 'Dylan');
