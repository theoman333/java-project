package demo.mavenproject1;

import java.util.List;


public class Main {
    public static void main(String[] args) {
        List<Show> shows = ShowManager.getShowsByArtist("Dylan");
        for (Show show : shows) {
            System.out.println("Show ID: " + show.getShowId());
            System.out.println("Show Time: " + show.getShowTime());
            System.out.println("Show Location: " + show.getShowLocation());
            System.out.println("Available Seats: " + show.getAvaliableSeats());
            System.out.println("Artist Name: " + show.getArtName().getArtistName());
            System.out.println("------------------------------");
        }
//        Runner.doLogic();
    }
}
