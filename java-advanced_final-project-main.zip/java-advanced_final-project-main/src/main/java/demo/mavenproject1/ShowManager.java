/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demo.mavenproject1;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class ShowManager {

    private static EntityManagerFactory emf = Persistence.createEntityManagerFactory("bla");

    
    public static List<Show> getShowsByArtist(String artistName) {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Show> query = em.createQuery("SELECT s FROM Show s WHERE s.artist.artistName = :art_name", Show.class);
        query.setParameter("artistName", artistName);
        List<Show> shows = query.getResultList();
        em.close();
        return shows;
    }
    
}





//public class Runner {
//    public static void doLogic() {
//        getAllArtists();
//    }
//    
//    
               
//    static List<Artist> getAllArtists(){
//        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
//        EntityManager entityManager = entityManagerFactory.createEntityManager();
//
//        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
//        CriteriaQuery<Artist> cq = cb.createQuery(Artist.class);
//        Root<Artist> from = cq.from(Artist.class);
//        cq.select(from);
//        TypedQuery<Artist> q = entityManager.createQuery(cq);
//
//        List<Artist> result = q.getResultList();
//        //HashSet<String> set = new HashSet<String>();
//        entityManager.close();
//        entityManagerFactory.close();
//        return result;
//    }
    
//    static List<Date> getDatesByArtist(String artistName) {
//        EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("default");
//        EntityManager entityManager = entityManagerFactory.createEntityManager();
//        List<Date> dates = entityManager.createQuery(
//            "SELECT e.date FROM MyEntity e WHERE e.artists = :artists", Date.class)
//            .setParameter("artists", artistName)
//            .getResultList();
//        entityManager.close();
//        entityManagerFactory.close();
//        return dates;
//    }
//    
//    static List<Show> getLocByArtDate(String artistName, Date date)
//}
